/** Automatically generated file. DO NOT MODIFY */
package com.cse5236groupthirteen;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}